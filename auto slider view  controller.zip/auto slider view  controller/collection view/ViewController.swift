//
//  ViewController.swift
//  collection view
//
//  Created by MAC OS on 25/01/22.
//

import UIKit

class ViewController: UIViewController {
    
     var currentcellIndex = 0
    
    var webSeriesImage = ["image1","image2","image3","image4","image5"]
    
    @IBOutlet var pageControl: UIPageControl!
    var timer:Timer?
   

    @IBOutlet var CollectionViewIB: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pageControl.numberOfPages = webSeriesImage.count
        timer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(slideToNext), userInfo: nil, repeats: true)
    }
    
    @objc func slideToNext()
    {
        if currentcellIndex < (webSeriesImage.count - 1)
        {
            currentcellIndex = (currentcellIndex + 1)
            pageControl.currentPage = currentcellIndex
        }
        else
        {
            currentcellIndex = 0
        }
        
        CollectionViewIB.scrollToItem(at: IndexPath(item: currentcellIndex, section:0), at: .right, animated: true)
        
    }


}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection  section: Int) -> Int {
        return webSeriesImage.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt   indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CollectionViewIB.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionView
        cell.MyImage.image = UIImage(named: webSeriesImage[indexPath.row])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CollectionViewIB.frame.width, height: CollectionViewIB.frame.height)
    }
    
    
    
}
