//
//  MyCollectionView.swift
//  collection view
//
//  Created by MAC OS on 25/01/22.
//

import UIKit

class MyCollectionView: UICollectionViewCell {
    
    
    
    @IBOutlet var MyImage: UIImageView!
    
    
}
