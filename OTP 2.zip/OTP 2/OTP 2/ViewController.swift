//
//  ViewController.swift
//  OTP 2
//
//  Created by MAC OS on 28/01/22.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    

   
   
    @IBOutlet var button: UIButton!
    @IBOutlet var txt1: UITextField!
    
    @IBOutlet var txt2: UITextField!
    @IBOutlet var txt3: UITextField!
    @IBOutlet var txt4: UITextField!
    
    override func viewDidLoad() {
            super.viewDidLoad()
            
            
            
            txt1.delegate = self
            txt2.delegate = self
            txt3.delegate = self
            txt4.delegate = self
            
        
        txt1.layer.cornerRadius = 30.0
        txt1.layer.borderWidth = 1.0
        txt1.layer.borderColor = UIColor.white.cgColor
        
        
        txt2.layer.cornerRadius = 30.0
        txt2.layer.borderWidth = 1.0
        txt2.layer.borderColor = UIColor.white.cgColor
        
        txt3.layer.cornerRadius = 30.0
        txt3.layer.borderWidth = 1.0
        txt3.layer.borderColor = UIColor.white.cgColor
        
        txt4.layer.cornerRadius = 30.0
        txt4.layer.borderWidth = 1.0
        txt4.layer.borderColor = UIColor.white.cgColor
        
        
        button.layer.cornerRadius = 30
  
        }

        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {


            if ((textField.text?.count)! < 1 ) && (string.count > 0) {
                if textField == txt1 {
                    txt2.becomeFirstResponder()
                }
                if textField == txt2 {
                    txt3.becomeFirstResponder()
                }
                if textField == txt3 {
                    txt4.becomeFirstResponder()
                }
                if textField == txt4 {
                    txt4.becomeFirstResponder()
                }
                textField.text = string
                return false
            }


            else if (textField.text?.count)! >= 1 && (string.count == 0 ) {
                if textField == txt2 {
                    txt1.becomeFirstResponder()
                }
                if textField == txt3 {
                    txt2.becomeFirstResponder()
                }
                if textField == txt4 {
                    txt3.becomeFirstResponder()
                }
                if textField == txt1 {
                    txt1.becomeFirstResponder()
                }
                textField.text = string
                return false

            }
           


            else if (textField.text?.count)! >= 1{
                textField.text = string

                return false
            }
            return false
        }
        
        
        
        
        

    }
