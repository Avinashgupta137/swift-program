//
//  ViewController.swift
//  OTP screen
//
//  Created by MAC OS on 27/01/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var CIRCLE1: UITextField!
    @IBOutlet var CIRCLE2: UITextField!
    @IBOutlet var CIRCLE3: UITextField!
    @IBOutlet var CIRCLE4: UITextField!
    
  
   
    @IBOutlet var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        CIRCLE1.layer.cornerRadius = 25.0
        CIRCLE1.layer.borderWidth = 1.0
        CIRCLE1.layer.borderColor = UIColor.white.cgColor
        
        
        CIRCLE2.layer.cornerRadius = 25.0
        CIRCLE2.layer.borderWidth = 1.0
        CIRCLE2.layer.borderColor = UIColor.white.cgColor
        
        CIRCLE3.layer.cornerRadius = 25.0
        CIRCLE3.layer.borderWidth = 1.0
        CIRCLE3.layer.borderColor = UIColor.white.cgColor
        
        CIRCLE4.layer.cornerRadius = 25.0
        CIRCLE4.layer.borderWidth = 1.0
        CIRCLE4.layer.borderColor = UIColor.white.cgColor
        
     button.layer.cornerRadius = 30
    }


}

